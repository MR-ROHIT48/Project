﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void CreateUserWizard1_FinishButtonClick(object sender, WizardNavigationEventArgs e)
    {
        Profile.FirstName = TextBox1.Text;
        Profile.LastName = TextBox2.Text;
        Profile.Address = TextBox3.Text;
        Profile.MobileNo = TextBox4.Text;
        Profile.SelectCity = DropDownList1.Text;
        Profile.SelectArea = DropDownList2.Text;
        if (FileUpload1.HasFile)
        {
            FileUpload1.SaveAs(Server.MapPath("~/Profilepic/" + FileUpload1.FileName));
            Profile.ProfilePic = FileUpload1.FileName;
        }
    }
}