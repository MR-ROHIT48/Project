﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class PriceList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = "Data Source=.//SQLEXPRESS;AttachDbFilename='C://Users//Lenovo//Desktop//Project//WebSite8 - Copy//App_Data//Database.mdf';Integrated Security=True;User Instance=True";
            cn.Open();
            string str = "SELECT dbo.Cloth.ClothType, dbo.Cloth_Service.Price FROM dbo.Cloth INNER JOIN dbo.Cloth_Service ON dbo.Cloth.ClothID = dbo.Cloth_Service.ClothID INNER JOIN dbo.Service ON dbo.Cloth_Service.ServiceID = dbo.Service.ServiceID";
            SqlDataAdapter da = new SqlDataAdapter(str,cn);
            DataSet view1 = new DataSet();
            da.Fill(view1);
            foreach (DataRow dr in view1.Tables[0].Rows)
            {
                Label11.Text += view1.Tables[0].Rows[0]["ClothType"].ToString();
            }
           
    }
}