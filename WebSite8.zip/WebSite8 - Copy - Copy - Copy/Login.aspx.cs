﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Security;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Login1_LoggedIn(object sender, EventArgs e)
    {
        if (Roles.IsUserInRole(Login1.UserName, "Admin"))
            Response.Redirect("~/Admin/Default.aspx");
        else if (Roles.IsUserInRole(Login1.UserName, "Employee"))
            Response.Redirect("~/Employee/Default.aspx");
        else
            Response.Redirect("~/home.aspx");

    }
}