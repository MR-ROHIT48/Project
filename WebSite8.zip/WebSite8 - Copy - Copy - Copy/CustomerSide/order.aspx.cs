﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class order : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = "Data Source=.//SQLEXPRESS;AttachDbFilename='C://Users//Lenovo//Desktop//Project//WebSite8 - Copy//App_Data//Database.mdf';Integrated Security=True;User Instance=True";
        cn.Open();
        DataTable dt = new DataTable();
        if (dt.Columns.Count == 0)
        {
            dt.Columns.Add("ClothType", typeof(string));
            dt.Columns.Add("ServiceName", typeof(string));
            dt.Columns.Add("Quantity", typeof(string));
       }
        DataRow NewRow = dt.NewRow();
        NewRow[0] = DropDownList1.Text;
        NewRow[1] = DropDownList3.Text;
        NewRow[2] = TextBox4.Text;
        dt.Rows.Add(NewRow);
        GridView1.DataSource = dt;
        GridView1.DataBind();
    }
}