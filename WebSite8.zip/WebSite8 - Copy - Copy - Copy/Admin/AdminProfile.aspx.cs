﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_AdminProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            TextBox1.Text = Profile.FirstName;
            TextBox2.Text = Profile.LastName;
            TextBox3.Text = Profile.Address;
            TextBox4.Text = Profile.MobileNo;
            TextBox5.Text = Profile.SelectCity;
            TextBox6.Text = Profile.SelectArea;
            Image1.ImageUrl = "~/Profilepic/" + Profile.ProfilePic;
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Profile.FirstName = TextBox1.Text;
        Profile.LastName = TextBox2.Text;
        Profile.Address = TextBox3.Text;
        Profile.MobileNo = TextBox4.Text;
        Profile.SelectCity = TextBox5.Text;
        Profile.SelectArea = TextBox6.Text;
        Response.Redirect("~/home.aspx");
    }
}