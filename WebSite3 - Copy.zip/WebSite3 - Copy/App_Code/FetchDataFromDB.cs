﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

/// <summary>
/// Summary description for FetchDataFromDB
/// </summary>
public class FetchDataFromDB
{
	public FetchDataFromDB()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public int FetchLastId(String sql)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        cn.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = sql;
        cmd.Connection = cn;
        int i = (int)cmd.ExecuteScalar();
        cn.Close();
        cmd.Dispose();
        return i;
    }
}