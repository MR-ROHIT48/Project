﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Security;

public partial class home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    SqlConnection cn = new SqlConnection(); 
    protected void Button2_Click(object sender, EventArgs e)
    {
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        cn.Open();
        string userid = Membership.GetUser().ProviderUserKey.ToString();
        SqlDataAdapter da = new SqlDataAdapter("SELECT dbo.[Order].*, dbo.Appointment.AppointmentID AS Expr1, dbo.Appointment.AppointmentDate, dbo.aspnet_Users.UserId FROM  dbo.Appointment INNER JOIN  dbo.aspnet_Users ON dbo.Appointment.UserId = "+userid+" INNER JOIN  dbo.[Order] ON dbo.Appointment.AppointmentID = dbo.[Order].AppointmentID", cn);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            Response.Write("~/CustomerSide/Appointment.aspx");
        }
        else
        {
            Response.Redirect("~/CustomerSide/order.aspx");
        }
        
    }
}