﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Security;

public partial class order : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        cn.Open();
        /* get address */
        if (!Page.IsPostBack)
        {
            TextBox2.Text = Profile.Address;
        }
        Calendar1.VisibleDate = DateTime.Today;
       
    }
    protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
    {
        if (e.Day.Date.CompareTo(DateTime.Today) < 0)
        {
            e.Day.IsSelectable = false;
        }
    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        TextBox1.Text = Calendar1.SelectedDate.ToShortDateString();
        Calendar1.Visible = false;
        Panel3.Visible = true;
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
      
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
            cn.Open();
            var i = HttpContext.Current.User.Identity.Name;
            string userid = Membership.GetUser().ProviderUserKey.ToString();
            string sql = "Insert into Appointment (AppointmentDate,UserId) Values('" + Calendar1.SelectedDate.ToString("MM/dd/yyyy") + "' ,'" + userid + "') ";
            SqlCommand cmd = new SqlCommand(sql, cn);
            Response.Write("<script>alert('Appointment Request.. ')</script>");
            cmd.ExecuteNonQuery();
            cn.Close();
           
            
    }
    private void Calculate(int b)
    {
        SqlConnection cn = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\ASPNETDB.MDF;Integrated Security=True;User Instance=True");
        SqlCommand cmd = new SqlCommand();
        cn.Open();
        cmd.CommandText = "Select Price From Cloth_Service Where ClothID = " + DropDownList1.Text + "and ServiceID = " + DropDownList4.Text;
        cmd.Connection = cn;
        int a = Convert.ToInt16(cmd.ExecuteScalar());
        int c = (b * a);
        Label9.Text = Convert.ToString(c);
        

    }
    private void BindGrid(int rowcount)
    {
        DataTable dt = new DataTable();
        DataRow dr;
        dt.Columns.Add("ClothType", typeof(string));
        dt.Columns.Add("ServiceName", typeof(string));
        dt.Columns.Add("Quantity", typeof(string));
        Calculate(Convert.ToInt16(TextBox4.Text));
        dt.Columns.Add("TotalPrice", typeof(string));

        if (ViewState["Cloth_Service"] != null)
        {
             for (int i = 0; i < rowcount + 1; i++)
             {
                 dt = (DataTable)ViewState["Cloth_Service"]; 
                 if (dt.Rows.Count > 0) 
                 {
                     dr = dt.NewRow(); 
                     dr[0] = dt.Rows[0][0].ToString();
                 }
             } 
            dr = dt.NewRow();
            dr[0] = Convert.ToString( DropDownList1.SelectedItem );
            dr[1] = Convert.ToString(DropDownList3.SelectedItem);
            dr[2] = TextBox4.Text;
            dr[3] = Label9.Text;
            dt.Rows.Add(dr);
        } 
        else 
        {
            dr = dt.NewRow();
            dr[0] = Convert.ToString(DropDownList1.SelectedItem);
            dr[1] = Convert.ToString(DropDownList3.SelectedItem);
            dr[2] = TextBox4.Text;
            dr[3] = Label9.Text;
            dt.Rows.Add(dr);
        } // If ViewState has a data then use the value as the DataSource 
        if (ViewState["Cloth_Service"] != null) 
        {
            GridView1.DataSource = (DataTable)ViewState["Cloth_Service"];
            GridView1.DataBind(); 
        }
        else
        { 
            // Bind GridView with the initial data assocaited in the DataTable 
            GridView1.DataSource = dt; GridView1.DataBind();
        } // Store the DataTable in ViewState to retain the values 
        ViewState["Cloth_Service"] = dt;

      
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        if (ViewState["Cloth_Service"] != null) 
        {
            DataTable dt = (DataTable)ViewState["Cloth_Service"];
            int count = dt.Rows.Count; BindGrid(count); 
        } 
        else
        { 
            BindGrid(1);
        } 
        TextBox4.Text = string.Empty; 
        TextBox4.Focus();

        Label11.Text = "0";
        for (int i = 0; i < GridView1.Rows.Count; i++)
        {
            Label11.Text = Convert.ToString(Convert.ToInt16(Label11.Text) + Convert.ToInt16(GridView1.Rows[i].Cells[3].Text)) ;
        }
        Session["totalprice"] = Label11.Text;
      
    }

    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {
        if (RadioButton1.Checked)
        {
            Panel1.Visible = true;
            Panel2.Visible =false;
            Session["rb1"] = RadioButton1.Text;
        }
    }
    protected void RadioButton3_CheckedChanged(object sender, EventArgs e)
    {
        if (RadioButton3.Checked)
        {
            Panel2.Visible = true;
            Panel1.Visible = false;
            Session["rb1"] = RadioButton1.Text;
        }
        //Panel1.Visible = false;
    }
    protected void TextBox3_TextChanged(object sender, EventArgs e)
    {
      
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        cn.Open();
        SqlCommand cmd;
        cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandText = "SELECT MAX(AppointmentID) FROM Appointment";
        int a_id = Convert.ToInt16(cmd.ExecuteScalar());
        a_id++;
        var i = HttpContext.Current.User.Identity.Name;
        string userid = Membership.GetUser().ProviderUserKey.ToString();
        string sql = "Insert into Appointment (AppointmentID,AppointmentDate,UserId) Values('" + a_id + "','" + Calendar1.SelectedDate.ToString("MM/dd/yyyy") + "' ,'" + userid + "') ";
        cmd = new SqlCommand(sql, cn);
        //Response.Write("<script>alert('Appointment Request.. ')</script>");
        cmd.ExecuteNonQuery();
        //cmd.Connection = cn; 
        //Panel3.Visible = true;
        cmd.CommandText = "SELECT MAX(OrderID) FROM [Order]";
        int o_id = Convert.ToInt16(cmd.ExecuteScalar());
        o_id++;
        // DateTime date = Convert.ToDateTime(DateTime.Now.ToString());
        string o_am = Convert.ToString(Label11.Text);
        cmd.CommandText = "Insert into [Order] (OrderID,OrderDate,OrderAmt,AppointmentID) Values('" + o_id + "','" + Calendar1.SelectedDate.ToString("MM/dd/yyyy") + "' ,'" + o_am + "','" + a_id + "') ";
        cmd.ExecuteNonQuery();

        //for order details 

        int x = GridView1.Rows.Count;
        int ff = 121;
        for (int ix = 0; ix < GridView1.Rows.Count; ix++)
        {
            //string status= GridView1.Rows[0].Cells[9].Text;
            //int clo_id = 1;

            cmd.CommandText = "SELECT MAX(OrderDetailID) FROM OrderDetail";
            int od_id = Convert.ToInt16(cmd.ExecuteScalar());
            od_id++;

            string ser_name = (GridView1.Rows[ix].Cells[1].Text);
            string clo_name = (GridView1.Rows[ix].Cells[0].Text);
            cmd.CommandText = "SELECT ClothID FROM Cloth WHERE ClothType='" + clo_name + "'";
            int clo_id = Convert.ToInt16(cmd.ExecuteScalar());
            cmd.CommandText = "SELECT ServiceID FROM Service WHERE ServiceName='" + ser_name + "'";
            int ser_id = Convert.ToInt16(cmd.ExecuteScalar());

            int qun = Convert.ToInt16(GridView1.Rows[ix].Cells[2].Text);
            string price = GridView1.Rows[ix].Cells[3].Text;
            cmd.CommandText = "Insert into OrderDetail (OrderDetailID,OrderID,ClothID,ServiceID,Quantity,Price,UserId) Values('" + od_id + "','" + o_id + "','" + clo_id + "' ,'" + ser_id + "','" + qun + "','" + price + "','" + userid + "') ";
            cmd.ExecuteNonQuery();
            Response.Write("<script>alert('Book Now')</script>");
            }
    
        Response.Redirect("~/CustomerSide/Invoice.aspx?OrderID=" + o_id);
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Calendar1.Visible = true;
    }
}