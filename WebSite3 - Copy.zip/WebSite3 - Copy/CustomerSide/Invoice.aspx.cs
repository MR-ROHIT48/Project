﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Invoice : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label6.Text = Request.QueryString["OrderID"];
        SqlConnection cn = new SqlConnection();

        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        cn.Open();

        String query = "SELECT dbo.Cloth.ClothType, dbo.Service.ServiceName, dbo.OrderDetail.Quantity, dbo.OrderDetail.Price, dbo.[Order].OrderAmt FROM dbo.OrderDetail INNER JOIN dbo.[Order] ON dbo.OrderDetail.OrderID = dbo.[Order].OrderID INNER JOIN dbo.Cloth ON dbo.OrderDetail.ClothID = dbo.Cloth.ClothID INNER JOIN dbo.Service ON dbo.OrderDetail.ServiceID = dbo.Service.ServiceID Where dbo.OrderDetail.OrderID = " + Label6.Text;
        DataTable dt = new DataTable();
        SqlDataAdapter da = new SqlDataAdapter(query, cn);
        da.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();
        Label8.Text = Profile.FirstName;
        Label11.Text = Profile.LastName;
        Label12.Text = Profile.Address;
        Label13.Text = Profile.MobileNo;
        Label10.Text = Session["rb1"].ToString();
        String j="₹";
        Label1.Text =j+ Session["totalprice"].ToString();
      
       String i = "₹ 45";
        Label2.Text =i;
        Label5.Text = "₹ 145";
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

    }
}