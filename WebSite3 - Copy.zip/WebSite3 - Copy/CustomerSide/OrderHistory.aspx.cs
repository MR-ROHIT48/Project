﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Security;

public partial class CustomerSide_OrderHistory : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        bindgrid();
    }
    private void bindgrid()
    {
        if (cn.State == ConnectionState.Closed)
        {
            cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
            cn.Open();
        }

        var i = HttpContext.Current.User.Identity.Name;
        string userid = Membership.GetUser().ProviderUserKey.ToString();
        SqlCommand cmd = new SqlCommand("SELECT dbo.[Order].OrderDate, dbo.[Order].OrderStatus, dbo.[Order].ShippingCharge, dbo.[Order].OrderAmt,dbo.[Order].PackageID FROM dbo.Appointment INNER JOIN dbo.[Order] ON dbo.Appointment.AppointmentID = dbo.[Order].AppointmentID where dbo.Appointment.UserId = @appuserid",cn);
        cmd.Parameters.AddWithValue("@appuserid", userid);
        cmd.Connection = cn;
        SqlDataReader dr = cmd.ExecuteReader();
        GridView1.DataSource = dr;
        GridView1.DataBind();
        cn.Close();

    }
    private void bindorderdetail()
    {

        if (cn.State == ConnectionState.Closed)
        {
            cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
            cn.Open();
        }
        string userid = Membership.GetUser().ProviderUserKey.ToString();
        SqlCommand cmd = new SqlCommand("SELECT dbo.OrderDetail.OrderDetailID, dbo.OrderDetail.OrderID, dbo.Cloth.ClothType, dbo.Service.ServiceName, dbo.OrderDetail.Quantity, dbo.Cloth_Service.Price, dbo.aspnet_Users.UserName FROM  dbo.Cloth INNER JOIN dbo.Cloth_Service ON dbo.Cloth.ClothID = dbo.Cloth_Service.ClothID INNER JOIN dbo.OrderDetail ON dbo.Cloth.ClothID = dbo.OrderDetail.ClothID INNER JOIN dbo.Service ON dbo.Cloth_Service.ServiceID = dbo.Service.ServiceID AND dbo.OrderDetail.ServiceID = dbo.Service.ServiceID INNER JOIN  dbo.aspnet_Users ON dbo.OrderDetail.UserId = dbo.aspnet_Users.UserId where dbo.OrderDetail.UserId = @oduserid", cn);
        cmd.Parameters.AddWithValue("@oduserid", userid);
        SqlDataReader dr = cmd.ExecuteReader();
        GridView2.DataSource = dr;
        GridView2.DataBind();
        cn.Close();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        GridView2.Visible = true;
        bindorderdetail();
    }
}