﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;

public partial class Appointment : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Calendar1.VisibleDate = DateTime.Today;

    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        TextBox1.Text = Calendar1.SelectedDate.ToString();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        cn.Open();
        var i=HttpContext.Current.User.Identity.Name;
       string userid= Membership.GetUser().ProviderUserKey.ToString();
       string sql = "Insert into Appointment (AppointmentDate,UserId) Values('" + Calendar1.SelectedDate.ToString("MM/dd/yyyy") + "' , '" + userid + "') ";
       SqlCommand cmd = new SqlCommand(sql, cn);
       cmd.ExecuteNonQuery();
       Response.Write("<script>alert('Appointment Request.. ')</script>");
       cn.Close();
    }
    protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
    {
        if (e.Day.Date.CompareTo(DateTime.Today) < 0)
        {
            e.Day.IsSelectable = false;
        }
    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        TextBox1.Text = Calendar1.SelectedDate.ToShortDateString();
    }
}