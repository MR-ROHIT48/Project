﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Security;



public partial class CustomerSide_ViewAppointment : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        bindgrid();
    }
    private void bindgrid()
    {
        if (cn.State == ConnectionState.Closed)
        {
            cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
            cn.Open();
        }
        var i = HttpContext.Current.User.Identity.Name;
        
        string userid = Convert.ToString( Membership.GetUser().ProviderUserKey);
        SqlCommand cmd = new SqlCommand( " SELECT AppointmentDate, Status FROM dbo.Appointment where UserId =@userid ",cn);
        cmd.Parameters.AddWithValue("@userid", userid);
        cmd.Connection = cn;
        SqlDataReader dr = cmd.ExecuteReader();
        GridView1.DataSource = dr;
        GridView1.DataBind();
        cn.Close();

    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        SqlCommand cmd = new SqlCommand();
        string i = GridView1.DataKeys[e.RowIndex].Value.ToString();
        cmd.CommandText = "DELETE FROM [Appointment] WHERE [AppointmentID]=@AppointmentID";
        cmd.Parameters.AddWithValue("@AppointmentID", i);
        cmd.Connection = cn;
        cmd.ExecuteNonQuery();
        bindgrid();
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            foreach (Button button in e.Row.Cells[2].Controls.OfType<Button>())
            {
                if (button.CommandName == "Cancel Appointment")
                {
                    button.Attributes["onclick"] = "if(!confirm('Do you want to Cancel this Appointment ?')){return false;};";
                }
            }
        }
    }
}