﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class PriceList : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        cn.Open();
        string sql = " SELECT dbo.Cloth.ClothType, dbo.Service.ServiceName, dbo.Cloth_Service.Price, dbo.Category.CategoryID FROM dbo.Category INNER JOIN dbo.Cloth ON dbo.Category.CategoryID = dbo.Cloth.CategoryID INNER JOIN dbo.Cloth_Service ON dbo.Cloth.ClothID = dbo.Cloth_Service.ClothID INNER JOIN  dbo.Service ON dbo.Cloth_Service.ServiceID = dbo.Service.ServiceID WHERE  (dbo.Category.CategoryID = '" + DropDownList1.Text + "')";
        SqlDataAdapter da = new SqlDataAdapter(sql, cn);
        DataTable dt = new DataTable();
        da.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            if (e.Row.RowIndex % 5 == 0)
            {
                e.Row.Cells[0].Attributes.Add("rowspan", "5");
            }
            else
            {
                e.Row.Cells[0].Visible = false;
            }
        }
    }
}