﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using CrystalDecisions.CrystalReports.Engine;

public partial class Admin_Report_CustomerReport : System.Web.UI.Page
{
    ReportDocument rpt = new ReportDocument();
    protected void Page_Load(object sender, EventArgs e)
    {
        //rpt.Load(Server.MapPath("~/Report/CrystalReport8.rpt"));
        //SqlConnection cn = new SqlConnection();
        //cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        //cn.Open();
        //SqlCommand cmd = new SqlCommand("select FirstName,LastName,Address,MobileNo,Email,City,Area from Profile", cn);
        //SqlDataAdapter da = new SqlDataAdapter(cmd);
        //DataTable dt = new DataTable();
        //da.Fill(dt);
        //rpt.SetDataSource(dt);
        //CrystalReportViewer1.ReportSource = rpt;
        //CrystalReportViewer1.DataBind();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        rpt.Load(Server.MapPath("~/Report/CrystalReport.rpt"));
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        cn.Open();
        SqlCommand cmd = new SqlCommand("select FirstName,LastName,Address,MobileNo,Email,City,Area from Profile",cn);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        rpt.SetDataSource(dt);
        rpt.SetParameterValue("area", DropDownList1.Text);
        CrystalReportViewer1.ReportSource = rpt;
        CrystalReportViewer1.DataBind();
    }
}