﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using CrystalDecisions.CrystalReports.Engine;

public partial class Report_Order_report : System.Web.UI.Page
{
    ReportDocument rpt = new ReportDocument();
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        TextBox1.Text = DateTime.Now.ToString("dd/MM/yyyy");
        rpt.Load(Server.MapPath("~/Report/CrystalReport5.rpt"));
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        cn.Open();
        SqlCommand cmd = new SqlCommand("SELECT OrderDate, OrderStatus, ShippingCharge, OrderAmt FROM     dbo.[Order]", cn);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        rpt.SetDataSource(dt);
        rpt.SetParameterValue("od", TextBox1.Text);
        cmd.ExecuteScalar();
        CrystalReportViewer1.ReportSource = rpt;
        CrystalReportViewer1.DataBind();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox1.Text = DateTime.Now.Month.ToString();
        rpt.Load(Server.MapPath("~/Report/CrystalReport6.rpt"));
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        cn.Open();
        SqlCommand cmd = new SqlCommand("SELECT OrderDate, OrderStatus, ShippingCharge, OrderAmt FROM     dbo.[Order]", cn);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        rpt.SetDataSource(dt);
        cmd.ExecuteScalar();
        CrystalReportViewer1.ReportSource = rpt;
        CrystalReportViewer1.DataBind();
    }
}