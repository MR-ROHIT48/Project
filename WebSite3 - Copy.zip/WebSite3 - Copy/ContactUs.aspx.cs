﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Web.Security;

public partial class ContactUs : System.Web.UI.Page
{
    string email = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        var i = HttpContext.Current.User.Identity.Name;
        TextBox3.Text = i;
        var user = Membership.GetUser(HttpContext.Current.User.Identity.Name);
      
        if (user != null)
        {
            email = user.Email;
        }
       TextBox4.Text= email;
       TextBox5.Text = i;
       TextBox6.Text = email;
        
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        cn.Open();
        string userid = Membership.GetUser().ProviderUserKey.ToString();
        SqlCommand cmd = new SqlCommand("Insert into Feedback (FeedbackDesc,UserId) Values('" + TextBox2.Text + "' , '" + userid + "') ", cn);
        cmd.ExecuteNonQuery();
        Response.Write("<script>alert(' Your Feedback is submitted ')</script>");
        cn.Close();
        TextBox2.Text = null;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        cn.Open();
        string userid = Membership.GetUser().ProviderUserKey.ToString();
        SqlCommand cmd = new SqlCommand("Insert into Inquiry (InquiryDesc,UserId) Values('" + TextBox1.Text + "' , '" + userid + "') ", cn);
        cmd.ExecuteNonQuery();
        Response.Write("<script>alert(' Your Inquiry is submitted ')</script>");
        cn.Close();
        TextBox1.Text = null;
      
    }
    protected void Rating1_Changed(object sender, AjaxControlToolkit.RatingEventArgs e)
    {
        Label6.Text = Rating1.CurrentRating.ToString();

    }
    protected void Rating1_Click(object sender, AjaxControlToolkit.RatingEventArgs e)
    {
        Label6.Text = Rating1.CurrentRating.ToString();
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        cn.Open();
        string userid = Membership.GetUser().ProviderUserKey.ToString();
        SqlCommand cmd = new SqlCommand("Insert into Rating (RatingNumber,UserId) Values('" + Label6.Text + "' , '" + userid + "') ", cn);
        cmd.ExecuteNonQuery();
        cn.Close();
    }
}