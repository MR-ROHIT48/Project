﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Admin_orderadmin : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        bindgrid();
       
    }
    private void bindgrid()
    {
        if (cn.State == ConnectionState.Closed)
        {
            cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
            cn.Open();
        }
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "SELECT dbo.[Order].* FROM dbo.[Order]";
        cmd.Connection = cn;
        SqlDataReader dr = cmd.ExecuteReader();
        GridView1.DataSource = dr;
        GridView1.DataBind();
        cn.Close();

    }
    private void bindorderdetail()
    {

        if (cn.State == ConnectionState.Closed)
        {
            cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
            cn.Open();
        }
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "SELECT dbo.OrderDetail.OrderDetailID, dbo.OrderDetail.OrderID, dbo.Cloth.ClothType, dbo.Service.ServiceName, dbo.OrderDetail.Quantity, dbo.Cloth_Service.Price, dbo.aspnet_Users.UserName FROM  dbo.Cloth INNER JOIN dbo.Cloth_Service ON dbo.Cloth.ClothID = dbo.Cloth_Service.ClothID INNER JOIN dbo.OrderDetail ON dbo.Cloth.ClothID = dbo.OrderDetail.ClothID INNER JOIN dbo.Service ON dbo.Cloth_Service.ServiceID = dbo.Service.ServiceID AND dbo.OrderDetail.ServiceID = dbo.Service.ServiceID INNER JOIN  dbo.aspnet_Users ON dbo.OrderDetail.UserId = dbo.aspnet_Users.UserId";
        cmd.Connection = cn;
        SqlDataReader dr = cmd.ExecuteReader();
        GridView2.DataSource = dr;
        GridView2.DataBind();
        cn.Close();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        GridView2.Visible = true;
        bindorderdetail();
    }
}