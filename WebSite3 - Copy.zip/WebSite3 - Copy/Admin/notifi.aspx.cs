﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Security;

public partial class Admin_notifi : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        cn.Open();
        SqlDataAdapter da = new SqlDataAdapter("SELECT dbo.Inquiry.InquiryID, dbo.Inquiry.InquiryDesc, dbo.Inquiry.Reply, dbo.Inquiry.UserId, dbo.aspnet_Users.UserName FROM dbo.aspnet_Users INNER JOIN dbo.Inquiry ON dbo.aspnet_Users.UserId = dbo.Inquiry.UserId", cn);
        DataTable dt = new DataTable();
        da.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        //string id1 = GridView1.DataKeys[e.RowIndex].Value.ToString();
        //string query1 = "DELETE FROM [Inquiry] WHERE [InquiryID]='" + id1 + "'";
        //SqlCommand cmd2 = new SqlCommand(query1, cn);
        //cmd2.ExecuteNonQuery();
        //GridView1.DataBind();
    }

    protected void GridView1_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        string args = btn.CommandArgument;
        Response.Redirect("~/Admin/replynotification.aspx?InquiryID=" + args);
    }
}