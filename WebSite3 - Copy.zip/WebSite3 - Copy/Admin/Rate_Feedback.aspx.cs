﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Admin_Rate_Feedback : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        cn.Open();
        SqlDataAdapter da = new SqlDataAdapter("SELECT dbo.Feedback.FeedbackID, dbo.Feedback.FeedbackDesc, dbo.aspnet_Users.UserName  FROM  dbo.aspnet_Users INNER JOIN  dbo.Feedback ON dbo.aspnet_Users.UserId = dbo.Feedback.UserId ", cn);
        DataTable dt = new DataTable();
        da.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();

        SqlDataAdapter da1 = new SqlDataAdapter("SELECT dbo.Rating.RatingID, dbo.Rating.RatingNumber, dbo.aspnet_Users.UserName FROM  dbo.aspnet_Users INNER JOIN  dbo.Rating ON dbo.aspnet_Users.UserId = dbo.Rating.UserId", cn);
        DataTable dt1 = new DataTable();
        da1.Fill(dt1);
        GridView2.DataSource = dt1;
        GridView2.DataBind();
    }
    protected void GridView2_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        int id = Convert.ToInt32(GridView2.DataKeys[e.RowIndex].Value.ToString());
        string query = "DELETE FROM [Rating] WHERE [RatingID]='" + id + "'";
        SqlCommand cmd1 = new SqlCommand(query, cn);
        cmd1.ExecuteNonQuery();
        GridView2.DataBind();
    }
    protected void GridView2_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        int id1 = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value.ToString());
        string query1 = "DELETE FROM [Feedback] WHERE [FeedbackID]='" + id1 + "'";
        SqlCommand cmd2 = new SqlCommand(query1, cn);
        cmd2.ExecuteNonQuery();
        GridView1.DataBind();
    }
}