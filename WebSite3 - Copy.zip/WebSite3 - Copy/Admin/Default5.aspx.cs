﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Admin_Default5 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection();
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        cn.Open();
        String sql = "select count(UserId) from aspnet_UsersInRoles where RoleId in ('abe421ec-7f8c-42e7-9590-d643d388e522')";
        SqlCommand cmd = new SqlCommand(sql, cn);
        DataSet ds = new DataSet();
        Label1.Text = Convert.ToString(cmd.ExecuteScalar());


        SqlDataAdapter da = new SqlDataAdapter("select FirstName,LastName,Address,MobileNo,Email,City,Area from Profile where UserId=(select UserId from aspnet_UsersInRoles where RoleId in ('abe421ec-7f8c-42e7-9590-d643d388e522'))", cn);
        DataTable dt = new DataTable();
        da.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();
    }
}