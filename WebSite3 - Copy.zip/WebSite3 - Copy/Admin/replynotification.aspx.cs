﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Admin_replynotification : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["InquiryID"] != null)
        {
            int id = Convert.ToInt16(Request.QueryString["InquiryID"].ToString());
            String con = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
            String query = "select * from Inquiry where InquiryID=" + id;
            SqlConnection cn = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = query;
            cmd.Connection = cn;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Label5.Text = ds.Tables[0].Rows[0]["InquiryID"].ToString();
                Label6.Text = ds.Tables[0].Rows[0]["InquiryDesc"].ToString();
                Label7.Text = ds.Tables[0].Rows[0]["UserId"].ToString();
            }
            else
            {
                Response.Redirect("~/Admin/notifi.aspx");
            }
        }


    }
    protected void Button1_Click(object sender, EventArgs e)
    {

            string a = Request.QueryString["InquiryID"];
            String con = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
            String updatedata = "Update Inquiry set Reply=@Reply Where InquiryId=" + a;
            SqlConnection cn = new SqlConnection(con);
            cn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = updatedata;
            cmd.Parameters.Add("@Reply", TextBox1.Text);
            cmd.Connection = cn;
            cmd.ExecuteNonQuery();
            Response.Write("<script>alert('Reply Send..!')</script>");
            Response.Redirect("~/Admin/notifi.aspx");
    }
}