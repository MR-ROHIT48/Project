﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Security;

public partial class Default2 : System.Web.UI.Page
{
    int for_enable = 0;
    SqlConnection cn = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
       
            cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
            cn.Open();
            String sql = "select count(UserId) from Profile";
            SqlCommand cmd = new SqlCommand(sql, cn);
            DataSet ds = new DataSet();
            Label1.Text = Convert.ToString(cmd.ExecuteScalar());


            SqlDataAdapter da = new SqlDataAdapter("SELECT dbo.Profile.UserId,dbo.Profile.FirstName, dbo.Profile.LastName, dbo.Profile.Address, dbo.Profile.MobileNo, dbo.Profile.Email, dbo.Profile.City, dbo.Profile.Area FROM   dbo.Profile ", cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            cn.Close();
       
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
            for_enable = 1;

            Response.Write("<script>alert('User Enable')</script>");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
            for_enable = 2;
            Response.Write("<script>alert('User Disable')</script>");
    
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        cn.Open();
        int rid = Convert.ToInt32(e.CommandArgument);
        string b = GridView1.Rows[rid].Cells[0].Text;
        SqlCommand cmd;
        cmd = new SqlCommand();
        cmd.Connection = cn;
        cmd.CommandText = "SELECT UserName FROM aspnet_Users WHERE UserId='" + b + "'";
        string c = Convert.ToString(cmd.ExecuteScalar());
        if (for_enable == 1)
        {
            MembershipUser us = Membership.GetUser(c);
                us.IsApproved = true;
                Membership.UpdateUser(us);
        }
        else if (for_enable == 2)
        {
            MembershipUser us = Membership.GetUser(c);
                us.IsApproved = false;
                Membership.UpdateUser(us);
        }
    }
}
