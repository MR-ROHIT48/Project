﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        cn.Open();
        String sql = "select count(AppointmentID) from Appointment where AppointmentDate = CONVERT(DATE,GETDATE())";
        SqlCommand cmd = new SqlCommand(sql,cn);
        DataSet ds = new DataSet();
        Label3.Text = Convert.ToString(cmd.ExecuteScalar());

        String sql1 = " select count(OrderID) from dbo.[Order] where OrderDate=CONVERT(DATE,GETDATE())";
        SqlCommand cmd1 = new SqlCommand(sql1, cn);
        DataSet ds1 = new DataSet();
        Label2.Text=Convert.ToString(cmd1.ExecuteScalar());

        cntcustomer();
        cntemp();
        
        //today appointment
        SqlDataAdapter da = new SqlDataAdapter("SELECT dbo.Appointment.AppointmentID, dbo.Appointment.AppointmentDate,dbo.Appointment.Status, dbo.aspnet_Users.UserName FROM  dbo.Appointment INNER JOIN  dbo.aspnet_Users ON dbo.Appointment.UserId = dbo.aspnet_Users.UserId Where dbo.Appointment.AppointmentDate =CONVERT(DATE,GETDATE())", cn);
        DataTable dt = new DataTable();
        da.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();

        SqlDataAdapter da1 = new SqlDataAdapter("SELECT dbo.[Order].OrderID, dbo.[Order].OrderDate, dbo.[Order].OrderStatus, dbo.[Order].ShippingCharge, dbo.[Order].OrderAmt, dbo.Appointment.AppointmentID, dbo.[Order].PackageID FROM  dbo.Appointment INNER JOIN  dbo.[Order] ON dbo.Appointment.AppointmentID = dbo.[Order].AppointmentID WHERE dbo.[Order].OrderDate = CONVERT(DATE,GETDATE())", cn);
        DataTable dt1 = new DataTable();
        da1.Fill(dt1);
        GridView2.DataSource = dt1;
        GridView2.DataBind();
    }
    private void cntcustomer()
    {
        if (cn.State == ConnectionState.Closed)
        {
            cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
            cn.Open();
        }
        String sql = "select count(*) from Profile";
        SqlCommand cmd = new SqlCommand(sql, cn);
        DataSet ds2 = new DataSet();
        Label5.Text = Convert.ToString(cmd.ExecuteScalar());
    }
    private void cntemp()
    {
        if (cn.State == ConnectionState.Closed)
        {
            cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
            cn.Open();
        }
        String sql = "select count(UserId) from aspnet_UsersInRoles where RoleId in ('abe421ec-7f8c-42e7-9590-d643d388e522')";
        SqlCommand cmd = new SqlCommand(sql, cn);
        DataSet ds2 = new DataSet();
        Label7.Text = Convert.ToString(cmd.ExecuteScalar());
    }
}