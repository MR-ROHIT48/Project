﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Security;

public partial class Admin_AdminProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            TextBox1.Text = Profile.FirstName;
            TextBox2.Text = Profile.LastName;
            TextBox3.Text = Profile.Address;
            TextBox4.Text = Profile.MobileNo;
            TextBox5.Text = Profile.SelectCity;
            TextBox6.Text = Profile.SelectArea;
            Image1.ImageUrl = "~/Profilepic/" + Profile.ProfilePic;
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Profile.FirstName = TextBox1.Text;
        Profile.LastName = TextBox2.Text;
        Profile.Address = TextBox3.Text;
        Profile.MobileNo = TextBox4.Text;
        Profile.SelectCity = TextBox5.Text;
        Profile.SelectArea = TextBox6.Text;
       


        String con = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        string userid = Membership.GetUser().ProviderUserKey.ToString();
        String updatedata = "Update Profile Set FirstName=@FirstName,LastName=@LastName,Address=@Address,MobileNo=@MobileNo,City=@City,Area=@Area Where UserId=@UserId";
        SqlConnection cn = new SqlConnection(con);
        cn.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = updatedata;
        cmd.Parameters.Add("@FirstName", TextBox1.Text);
        cmd.Parameters.Add("@LastName", TextBox2.Text);
        cmd.Parameters.Add("@Address", TextBox3.Text);
        cmd.Parameters.Add("@MobileNo", TextBox4.Text);
        cmd.Parameters.Add("@City", TextBox5.Text);
        cmd.Parameters.Add("@Area", TextBox6.Text);
        cmd.Parameters.Add("@UserId", userid);
        cmd.Connection = cn;
        cmd.ExecuteNonQuery();
        Response.Write("<script>alert('Profile has Updated')</script>");
        Response.Redirect("~/Admin/Default.aspx");
        
    }
    protected void ChangePasswordPushButton_Click(object sender, EventArgs e)
    {
        Response.Write(@"<script language='javascript'>aleart('Change Password Successfully')</script>");
    }
}