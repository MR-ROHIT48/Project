﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Default3 : System.Web.UI.Page
{
        SqlConnection cn = new SqlConnection();
       FetchDataFromDB obj = new FetchDataFromDB();
    protected void Page_Load(object sender, EventArgs e)
    {
       
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
            FormView1.Visible = true;
            FormView1.ChangeMode(FormViewMode.Insert);
            int i = obj.FetchLastId("Select MAX(ClothID) from Cloth");
            i = i + 1;
            System.Web.UI.WebControls.TextBox tx = (System.Web.UI.WebControls.TextBox)FormView1.FindControl("ClothIDTextBox");
            tx.Text = Convert.ToString(i);
    }
    protected void InsertButton_Click1(object sender, EventArgs e)
    {
        System.Web.UI.WebControls.TextBox tx1 = (System.Web.UI.WebControls.TextBox)FormView1.FindControl("CategoryIDTextBox");
        if (tx1.Text == null)
            tx1.Text = Convert.ToString("text");
        Response.Write("<script>alert('New ClothType Added')</script>");
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        System.Web.UI.WebControls.TextBox tx = (System.Web.UI.WebControls.TextBox)FormView1.FindControl("CategoryIDTextBox");
        DropDownList dr = (DropDownList)FormView1.FindControl("DropDownList2");
        tx.Text = dr.SelectedValue;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        FormView2.Visible = true;
        FormView2.ChangeMode(FormViewMode.Insert);
        int i = obj.FetchLastId("Select MAX(ServiceID) from Service");                           
        i = i + 1;
        System.Web.UI.WebControls.TextBox tx1 = (System.Web.UI.WebControls.TextBox)FormView2.FindControl("ServiceIDTextBox");
        tx1.Text = Convert.ToString(i);
    }
  
    protected void InsertButton_Click(object sender, EventArgs e)
    {

        System.Web.UI.WebControls.TextBox tx1 = (System.Web.UI.WebControls.TextBox)FormView2.FindControl("ServiceIDTextBox");
        if (tx1.Text == null)
            tx1.Text = Convert.ToString("text");
        Response.Write("<script>alert('New Service Added')</script>");
    }
    protected void FormView1_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
    {
        FormView1.Visible = false;
        Response.Redirect("Default3.aspx");
    }
    protected void FormView1_ModeChanged(object sender, EventArgs e)
    {
        FormView1.Visible = false;
        Response.Redirect("Default3.aspx");
    }
    protected void FormView2_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
    {
        FormView2.Visible = false;
        Response.Redirect("Default3.aspx");
    }
    protected void FormView2_ModeChanged(object sender, EventArgs e)
    {
        FormView2.Visible = false;
        Response.Redirect("Default3.aspx");
    }
    
   

   
}