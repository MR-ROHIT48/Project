﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default4 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        FormView1.Visible = true;
        FormView1.ChangeMode(FormViewMode.Insert);
        FetchDataFromDB obj = new FetchDataFromDB();
        int i = obj.FetchLastId("Select MAX(PackageID) from Package");
        i = i + 1;
        System.Web.UI.WebControls.TextBox tx = (System.Web.UI.WebControls.TextBox)FormView1.FindControl("PackageIDTextBox");
        tx.Text = Convert.ToString(i);
    }
    protected void FormView1_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
    {
        FormView1.Visible = false;
        Response.Redirect("Default4.aspx");
    }
    protected void FormView1_ModeChanged(object sender, EventArgs e)
    {
        FormView1.Visible = false;
        Response.Redirect("Default4.aspx");
    }
}