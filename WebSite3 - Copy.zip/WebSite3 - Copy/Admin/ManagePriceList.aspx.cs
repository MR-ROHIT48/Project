﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Admin_ManagePriceList : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection(); 
    protected void Page_Load(object sender, EventArgs e)
    {
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        cn.Open();
        SqlDataAdapter da = new SqlDataAdapter("SELECT dbo.Cloth.ClothType, dbo.Service.ServiceName, dbo.Cloth_Service.Price FROM  dbo.Cloth INNER JOIN dbo.Cloth_Service ON dbo.Cloth.ClothID = dbo.Cloth_Service.ClothID INNER JOIN dbo.Service ON dbo.Cloth_Service.ServiceID = dbo.Service.ServiceID", cn);
        DataTable dt = new DataTable();
        da.Fill(dt);
        GridView3.DataSource = dt;
        GridView3.DataBind();
        FormView3.DataSource = dt;
        FormView3.DataBind();
    }
    protected void GridView3_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView3.EditIndex = e.NewEditIndex;
        GridView3.DataBind();
    }
    protected void GridView3_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView3.PageIndex = e.NewPageIndex;
        GridView3.DataBind();
    }
    protected void GridView3_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        GridView3.EditIndex = -1;
    }
    protected void GridView3_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView3.EditIndex = -1;
        GridView3.DataBind();

    }
    protected void GridView3_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        int id1 = Convert.ToInt32(GridView3.DataKeys[e.RowIndex].Value.ToString());
        string query1 = "DELETE FROM [Cloth_Service] WHERE [ClothID]='" + id1 + "'";
        SqlCommand cmd2 = new SqlCommand(query1, cn);
        cmd2.ExecuteNonQuery();
        GridView3.DataBind();
    }

    protected void GridView3_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            if (e.Row.RowIndex % 5 == 0)
            {
                e.Row.Cells[0].Attributes.Add("rowspan", "5");
            }
            else
            {
                e.Row.Cells[0].Visible = false;
            }
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        FormView3.Visible = true;
        FormView3.ChangeMode(FormViewMode.Insert);
    }

}