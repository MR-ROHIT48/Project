﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Web.Security;
using System.Data.SqlClient;
using System.Data;

public partial class Admin_Default6 : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            bindgrid();
        }
        cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        cn.Open();
        String sql = "select count(AppointmentID) from Appointment";
        SqlCommand cmd = new SqlCommand(sql, cn);
        DataSet ds = new DataSet();
        Label9.Text = Convert.ToString(cmd.ExecuteScalar());
    }
    private void bindgrid()
    {
        if (cn.State == ConnectionState.Closed)
        {
            cn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
            cn.Open();
        }
        SqlCommand cmd=new SqlCommand();
        cmd.CommandText = " SELECT dbo.Appointment.AppointmentID, dbo.Appointment.AppointmentDate, dbo.aspnet_Users.UserName FROM  dbo.Appointment INNER JOIN  dbo.aspnet_Users ON dbo.Appointment.UserId = dbo.aspnet_Users.UserId";
        cmd.Connection = cn;
        SqlDataReader dr = cmd.ExecuteReader();
        GridView1.DataSource = dr;
        GridView1.DataBind();
        cn.Close();

    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        //string email = null;

        //var user = Membership.GetUser(HttpContext.Current.User.Identity.Name);
        //if (user != null)
        //{
        //    email = user.Email;
        //}
        //SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
        //client.EnableSsl = true;
        //client.DeliveryMethod = SmtpDeliveryMethod.Network;
        //client.UseDefaultCredentials = false;
        //client.Credentials = new NetworkCredential("mylaundrybusiness@gmail.com", "@pN1L4un6Ry");
        //MailMessage msgobj = new MailMessage();
        //msgobj.To.Add("mylaundrybusiness@gmail.com");
        //msgobj.From = new MailAddress(email);
        //msgobj.Subject = "Appointment Rejected";
        //msgobj.Body = "Sloth is Not Sufficient Your Appointment is Rejected Please Again Request For Appointmnet";
        //client.Send(msgobj);
        
        SqlCommand cmd = new SqlCommand();
        string i = GridView1.DataKeys[e.RowIndex].Value.ToString();
        cmd.CommandText = "DELETE FROM [Appointment] WHERE [AppointmentID]=@AppointmentID";
        cmd.Parameters.AddWithValue("@AppointmentID", i);
        cmd.Connection = cn;
        cmd.ExecuteNonQuery();
        bindgrid();

     
    }
    protected void GridView1_DataBound(object sender, EventArgs e)
    {
       
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {


        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string item = e.Row.Cells[0].Text;
            foreach (Button button in e.Row.Cells[3].Controls.OfType<Button>())
            {
                if (button.CommandName == "Delete")
                {
                    button.Attributes["onclick"] = "if(!confirm('Do you want to Cancel this Appointment" + item + "?')){return false;};";
                }
            }
        }
    }
}