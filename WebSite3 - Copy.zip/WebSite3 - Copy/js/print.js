﻿
          function printpage() {

              var getpanel = document.getElementById("<%= Panel1.ClientID%>");
              var MainWindow = window.open('', '', 'height=500,width=800');
              MainWindow.document.write('<html><head><title>Print Page</title>');
              MainWindow.document.write('</head><body>');
              MainWindow.document.write(getpanel.innerHTML);
              MainWindow.document.write('</body></html>');
              MainWindow.document.close();
              setTimeout(function () {
                  MainWindow.print();
              }, 500);
              return false;

          }
